# Dsa-Final-Project-
Warehouse- The Solution to all your Data Problems

This project conatins a folder name app. please open that and you will see two more folders and a server.py file.

The server.py file is the main code load them in vs code or any other editor 

before running them write pip install flask in the command line to install package.

Run the program in the terminal 

The program will generate the link

follow that link ctrl+click

The webpage will open
